import { Pokemon } from "./Pokemon";

export const App = () => {
  return <Pokemon/>;
};